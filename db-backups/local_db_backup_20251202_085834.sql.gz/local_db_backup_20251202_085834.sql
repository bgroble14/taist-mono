-- MySQL dump 10.13  Distrib 9.5.0, for macos14.8 (arm64)
--
-- Host: localhost    Database: taist_local
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '210086fa-cf19-11f0-9576-6d08df47c712:1-134';

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (10,'2025_12_02_031241_add_acceptance_deadline_to_orders',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcm_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `navigation_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1043 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'Taist Personal Access Client','Z3IQt4dJzX2KvfvQZ7zFDdTtLqO4BDsVZzGcP79e',NULL,'http://localhost',1,0,0,'2025-12-02 07:00:21','2025-12-02 07:00:21'),(2,NULL,'Taist Password Grant Client','z8ZuPmYVl2S44DW2r3gRKUgZHFQQikqmejIT6Qd7','users','http://localhost',0,1,0,'2025-12-02 07:00:21','2025-12-02 07:00:21');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2025-12-02 07:00:21','2025-12-02 07:00:21');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admins`
--

DROP TABLE IF EXISTS `tbl_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint NOT NULL DEFAULT '1',
  `api_token` varchar(255) NOT NULL DEFAULT '',
  `remember_token` varchar(255) NOT NULL DEFAULT '',
  `login_location` varchar(255) DEFAULT '',
  `created_at` varchar(255) NOT NULL DEFAULT '',
  `updated_at` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admins`
--

LOCK TABLES `tbl_admins` WRITE;
/*!40000 ALTER TABLE `tbl_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_allergens`
--

DROP TABLE IF EXISTS `tbl_allergens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_allergens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_allergens`
--

LOCK TABLES `tbl_allergens` WRITE;
/*!40000 ALTER TABLE `tbl_allergens` DISABLE KEYS */;
INSERT INTO `tbl_allergens` VALUES (10,'Gluten','2025-12-02 01:01:46','2025-12-02 01:01:46'),(11,'Dairy','2025-12-02 01:01:46','2025-12-02 01:01:46'),(12,'Eggs','2025-12-02 01:01:46','2025-12-02 01:01:46'),(13,'Peanuts','2025-12-02 01:01:46','2025-12-02 01:01:46'),(14,'Tree Nuts','2025-12-02 01:01:46','2025-12-02 01:01:46'),(15,'Soy','2025-12-02 01:01:46','2025-12-02 01:01:46'),(16,'Fish','2025-12-02 01:01:46','2025-12-02 01:01:46'),(17,'Shellfish','2025-12-02 01:01:46','2025-12-02 01:01:46');
/*!40000 ALTER TABLE `tbl_allergens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_appliances`
--

DROP TABLE IF EXISTS `tbl_appliances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_appliances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_appliances`
--

LOCK TABLES `tbl_appliances` WRITE;
/*!40000 ALTER TABLE `tbl_appliances` DISABLE KEYS */;
INSERT INTO `tbl_appliances` VALUES (7,'Oven','oven.png','2025-12-02 01:01:46','2025-12-02 01:01:46'),(8,'Microwave','microwave.png','2025-12-02 01:01:46','2025-12-02 01:01:46'),(9,'Stovetop','stovetop.png','2025-12-02 01:01:46','2025-12-02 01:01:46'),(10,'Air Fryer','airfryer.png','2025-12-02 01:01:46','2025-12-02 01:01:46'),(11,'Instant Pot','instantpot.png','2025-12-02 01:01:46','2025-12-02 01:01:46'),(12,'Grill','grill.png','2025-12-02 01:01:46','2025-12-02 01:01:46');
/*!40000 ALTER TABLE `tbl_appliances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_availabilities`
--

DROP TABLE IF EXISTS `tbl_availabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_availabilities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `bio` mediumtext,
  `monday_start` varchar(50) DEFAULT NULL,
  `monday_end` varchar(50) DEFAULT NULL,
  `tuesday_start` varchar(50) DEFAULT NULL,
  `tuesday_end` varchar(50) DEFAULT NULL,
  `wednesday_start` varchar(50) DEFAULT NULL,
  `wednesday_end` varchar(50) DEFAULT NULL,
  `thursday_start` varchar(50) DEFAULT NULL,
  `thursday_end` varchar(50) DEFAULT NULL,
  `friday_start` varchar(50) DEFAULT NULL,
  `friday_end` varchar(50) DEFAULT NULL,
  `saterday_start` varchar(50) DEFAULT NULL,
  `saterday_end` varchar(50) DEFAULT NULL,
  `sunday_start` varchar(50) DEFAULT NULL,
  `sunday_end` varchar(50) DEFAULT NULL,
  `minimum_order_amount` double DEFAULT NULL,
  `max_order_distance` double DEFAULT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_availabilities`
--

LOCK TABLES `tbl_availabilities` WRITE;
/*!40000 ALTER TABLE `tbl_availabilities` DISABLE KEYS */;
INSERT INTO `tbl_availabilities` VALUES (107,1,'Specializing in authentic Mexican cuisine with 15 years of experience. My dishes are made with love and traditional recipes passed down through generations.','09:00','21:00','09:00','21:00','09:00','21:00','09:00','21:00','09:00','22:00','10:00','22:00','10:00','20:00',25,10,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(108,2,'Award-winning Asian fusion chef bringing bold flavors to your kitchen. Trained in Tokyo and Hong Kong, now sharing my passion in Chicago.','11:00','20:00','11:00','20:00','11:00','20:00','11:00','20:00','11:00','21:00','11:00','21:00',NULL,NULL,30,8,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(109,3,'Plant-based chef creating delicious vegan and vegetarian meals. Proving that healthy eating can be incredibly flavorful!','10:00','19:00','10:00','19:00','10:00','19:00','10:00','19:00','10:00','20:00','10:00','20:00','10:00','18:00',20,12,'2025-12-02 01:01:46','2025-12-02 01:01:46');
/*!40000 ALTER TABLE `tbl_availabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_categories`
--

DROP TABLE IF EXISTS `tbl_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `chef_id` int NOT NULL DEFAULT '0',
  `menu_id` int NOT NULL DEFAULT '0',
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1: Requested, 2: Approved, 3: Rejected',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_categories`
--

LOCK TABLES `tbl_categories` WRITE;
/*!40000 ALTER TABLE `tbl_categories` DISABLE KEYS */;
INSERT INTO `tbl_categories` VALUES (22,'Mexican',1,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(23,'Asian',2,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(24,'Vegan',3,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(25,'Italian',0,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(26,'American',0,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(27,'Indian',0,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(28,'Mediterranean',0,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2),(29,'BBQ',0,0,'2025-12-02 01:01:46','2025-12-02 01:01:46',2);
/*!40000 ALTER TABLE `tbl_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_conversations`
--

DROP TABLE IF EXISTS `tbl_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL DEFAULT '0',
  `from_user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `message` text NOT NULL,
  `is_viewed` tinyint NOT NULL DEFAULT '0',
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_conversations`
--

LOCK TABLES `tbl_conversations` WRITE;
/*!40000 ALTER TABLE `tbl_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customizations`
--

DROP TABLE IF EXISTS `tbl_customizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_customizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menu_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `upcharge_price` double NOT NULL,
  `created_at` varchar(50) DEFAULT NULL,
  `updated_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customizations`
--

LOCK TABLES `tbl_customizations` WRITE;
/*!40000 ALTER TABLE `tbl_customizations` DISABLE KEYS */;
INSERT INTO `tbl_customizations` VALUES (157,1,'Extra Guacamole',2.5,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(158,1,'Add Cheese',1.5,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(159,1,'Extra Spicy',0,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(160,7,'Extra Avocado',2,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(161,7,'Add Tempeh',3.5,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(162,6,'Double Portion',10,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(163,6,'Brown Rice Instead',0,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(164,142,'sdfsfsdfsfd',10,'2025-12-02 02:57:34','2025-12-02 02:57:34');
/*!40000 ALTER TABLE `tbl_customizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_menus`
--

DROP TABLE IF EXISTS `tbl_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_menus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `price` double NOT NULL,
  `serving_size` int NOT NULL DEFAULT '1',
  `meals` varchar(50) NOT NULL,
  `category_ids` varchar(50) NOT NULL,
  `allergens` varchar(50) DEFAULT NULL,
  `appliances` varchar(50) DEFAULT NULL,
  `estimated_time` double NOT NULL,
  `is_live` tinyint NOT NULL DEFAULT '0',
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_menus`
--

LOCK TABLES `tbl_menus` WRITE;
/*!40000 ALTER TABLE `tbl_menus` DISABLE KEYS */;
INSERT INTO `tbl_menus` VALUES (133,1,'Authentic Chicken Tacos (3 pack)','Three delicious tacos filled with seasoned grilled chicken, fresh cilantro, onions, and authentic Mexican salsa. Served with lime wedges.',15,1,'Lunch,Dinner','1','1','3,4',20,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(134,1,'Beef Enchiladas with Red Sauce','Tender beef wrapped in corn tortillas, smothered in homemade red enchilada sauce and melted cheese. Served with rice and beans.',22,2,'Dinner','1','1,2','1',35,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(135,1,'Veggie Quesadilla','Flour tortilla filled with a blend of cheeses, peppers, onions, and mushrooms. Served with sour cream and guacamole.',12,1,'Lunch,Dinner','1','1,2','3',15,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(136,2,'Kung Pao Chicken','Spicy stir-fried chicken with peanuts, vegetables, and chili peppers in a savory sauce. Served with steamed rice.',18,1,'Lunch,Dinner','2','4,6','3',25,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(137,2,'Pad Thai','Classic Thai rice noodles stir-fried with shrimp, tofu, eggs, bean sprouts, and crushed peanuts in tamarind sauce.',20,1,'Lunch,Dinner','2','3,4,6,8','3',20,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(138,2,'Teriyaki Salmon Bowl','Grilled salmon glazed with house-made teriyaki sauce, served over rice with steamed vegetables and sesame seeds.',25,1,'Lunch,Dinner','2','6,7','1,3',30,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(139,3,'Buddha Bowl','Quinoa bowl topped with roasted chickpeas, sweet potato, avocado, kale, and tahini dressing. Completely plant-based!',16,1,'Lunch,Dinner','3','','1',25,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(140,3,'Vegan Mushroom Risotto','Creamy arborio rice cooked with mixed mushrooms, garlic, white wine, and nutritional yeast. Rich and satisfying!',19,1,'Dinner','3','1','3',40,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(141,3,'Jackfruit Tacos (3 pack)','Pulled jackfruit seasoned with spices, served in corn tortillas with cabbage slaw, avocado, and cilantro-lime crema.',14,1,'Lunch,Dinner','3','','3',20,1,'2025-12-02 01:01:46','2025-12-02 01:01:46'),(142,210,'ASDFSADFSFD','SADFSAFDFASDFSDFASFD',50,4,'breakfast','23','15,14','1,8,9',120,1,'2025-12-02 02:57:34','2025-12-02 02:57:34');
/*!40000 ALTER TABLE `tbl_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_notification_templates`
--

DROP TABLE IF EXISTS `tbl_notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_notification_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `email` text,
  `push` varchar(200) DEFAULT NULL,
  `text` varchar(200) DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` varchar(50) DEFAULT NULL,
  `updated_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_notification_templates`
--

LOCK TABLES `tbl_notification_templates` WRITE;
/*!40000 ALTER TABLE `tbl_notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_orders`
--

DROP TABLE IF EXISTS `tbl_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chef_user_id` int NOT NULL,
  `menu_id` int NOT NULL,
  `customer_user_id` int NOT NULL,
  `amount` int NOT NULL,
  `total_price` double NOT NULL,
  `addons` varchar(50) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `order_date` varchar(50) NOT NULL,
  `acceptance_deadline` varchar(50) DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1: Requested, 2: Accepted, 3: Completed, 4: Cancelled, 5: Rejected, 6: Expired, 7: On my way',
  `notes` text,
  `payment_token` varchar(50) DEFAULT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_orders_status_deadline` (`status`,`acceptance_deadline`)
) ENGINE=InnoDB AUTO_INCREMENT=456 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_orders`
--

LOCK TABLES `tbl_orders` WRITE;
/*!40000 ALTER TABLE `tbl_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_payment_method_listener`
--

DROP TABLE IF EXISTS `tbl_payment_method_listener`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_payment_method_listener` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `stripe_account_id` varchar(50) NOT NULL DEFAULT '',
  `stripe_cus_id` varchar(50) NOT NULL,
  `card_token` varchar(255) NOT NULL DEFAULT '',
  `card_type` varchar(20) NOT NULL DEFAULT '',
  `last4` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) DEFAULT '',
  `active` tinyint NOT NULL DEFAULT '1',
  `created_at` varchar(255) DEFAULT '',
  `updated_at` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_payment_method_listener`
--

LOCK TABLES `tbl_payment_method_listener` WRITE;
/*!40000 ALTER TABLE `tbl_payment_method_listener` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_payment_method_listener` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_reviews`
--

DROP TABLE IF EXISTS `tbl_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `from_user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `rating` double NOT NULL,
  `review` text,
  `tip_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=329 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_reviews`
--

LOCK TABLES `tbl_reviews` WRITE;
/*!40000 ALTER TABLE `tbl_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tickets`
--

DROP TABLE IF EXISTS `tbl_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1: In Review, 2: Resolved\\n',
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tickets`
--

LOCK TABLES `tbl_tickets` WRITE;
/*!40000 ALTER TABLE `tbl_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_transactions`
--

DROP TABLE IF EXISTS `tbl_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `from_user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `amount` double NOT NULL,
  `notes` varchar(100) DEFAULT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_transactions`
--

LOCK TABLES `tbl_transactions` WRITE;
/*!40000 ALTER TABLE `tbl_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(50) NOT NULL DEFAULT '',
  `birthday` int DEFAULT NULL,
  `bio` text,
  `address` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `user_type` tinyint NOT NULL DEFAULT '1' COMMENT '1:customer,2:chef',
  `is_pending` tinyint NOT NULL DEFAULT '0' COMMENT '0:no,1:yes',
  `verified` tinyint NOT NULL DEFAULT '0' COMMENT '0:pending,1:active,2:deny,3:banned',
  `photo` varchar(255) NOT NULL DEFAULT '',
  `api_token` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `token_date` varchar(50) NOT NULL DEFAULT '',
  `applicant_guid` varchar(50) DEFAULT NULL,
  `order_guid` varchar(50) DEFAULT NULL,
  `fcm_token` varchar(200) DEFAULT NULL,
  `latitude` varchar(45) DEFAULT NULL,
  `longitude` varchar(45) DEFAULT NULL,
  `created_at` varchar(50) NOT NULL DEFAULT '',
  `updated_at` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'Maria','Rodriguez','maria.chef@test.com','$2y$10$Ws3veuJ8vUpJwKdwdjalf.Al4MFpEKAegIDWWQTH3mrHGfOwXS7jq','+13125551001',479692800,'Specializing in authentic Mexican cuisine with 15 years of experience.','123 W Madison St','Chicago','IL','60602',2,0,1,'chef1.jpg','xHdnkoJLgOBcxy0Z7UrG9RKAYFZeUyf6QM21ERQpAkOcdGPRjgrGgRRb0Q9E1PIDPQqPjN17oc3DVN9n','','',NULL,NULL,NULL,'41.8819','-87.6278','2025-12-02 01:01:46','2025-12-02 01:01:46'),(2,'James','Chen','james.chef@test.com','$2y$10$c5Mk8.dqvzMTpjDEqrMnm.NMEEW3lhdKLLrinbyP3gicYrqjeNX/6','+13125551002',648604800,'Award-winning Asian fusion chef bringing bold flavors to your kitchen.','456 N State St','Chicago','IL','60610',2,0,1,'chef2.jpg','YY2b8YQdzgomOAi90VGo81UY7TWE1pGm7pe5YvRWAccsJSAQfHKXS0kQJd2K54keRJzwDNMopHDKxnUm','','',NULL,NULL,NULL,'41.8968','-87.6283','2025-12-02 01:01:46','2025-12-02 01:01:46'),(3,'Sarah','Williams','sarah.chef@test.com','$2y$10$al/aoj5cysN7PpvsWVVfEub.7w9W4Eci0ups6zodMtMld7gXPmKZC','+13125551003',594950400,'Plant-based chef creating delicious vegan and vegetarian meals.','789 S Michigan Ave','Chicago','IL','60605',2,0,1,'chef3.jpg','y04K2humL8VR64DuOzjsKQ1WLn2F3QVHE89zGoQhOFYcJhRQR3hzE4EZStwygkovPdh1ykdFWlcPSRBT','','',NULL,NULL,NULL,'41.8681','-87.6245','2025-12-02 01:01:46','2025-12-02 01:01:46'),(4,'John','Smith','john.customer@test.com','$2y$10$HE6YwEPjp3glvgpHnuKpBe.peKBgp1SrGrJ7rKzs.EOLCHk3pJ./G','+13125552001',NULL,NULL,'321 E Ohio St','Chicago','IL','60611',1,0,1,'','YJW67VaZOZ8HtaA2DOZsHwpV7rkAnYEHQliggfyXQZIVb8r3qw0F3UuV6Tcfgu8be6RamS5wSU0Y7shG','','',NULL,NULL,NULL,'41.8922','-87.6189','2025-12-02 01:01:46','2025-12-02 01:01:46'),(5,'Emily','Johnson','emily.customer@test.com','$2y$10$jQyaODaHiAa8hzMjSwy2T.HTI6DGHKFB6Sm3EMEv3.Yeyiw1q0b1q','+13125552002',NULL,NULL,'654 W Randolph St','Chicago','IL','60661',1,0,1,'','BlnTuX4QdRPhcC7QwLDFxSh9zE85eyedyBJPE7i3SgOw264xdQ1gUPTsmOyOHQcOs4ll65IjmDMqgIAy','','',NULL,NULL,NULL,'41.8845','-87.6446','2025-12-02 01:01:46','2025-12-02 01:01:46'),(212,'Steve','Johnson','billgroble27@gmail.com','$2y$10$Oi/GPDQZQUDaVG/wSoR2veWqTJYd7HGFHQYZ7oqA.gNpbIFOWW2t6','2245351031',-475927020,NULL,'210 South Dearborn Street','Chicago','Illinois','60604',2,1,1,'user_photo_1764684334.jpg','MZYCS8DpjTYubWcjgO5GTILasVOQha692ef22ea471432dfcGAOJ4LTBqFrk9L2L6hauOvfRm','','',NULL,NULL,'eZcMRdNqSSKvinVtMH2VOz:APA91bE_ckQnNG-d82qxMU7ZcoVdCjn3jQ7FY4dbJrdicCF22ndsMqeVqN2Y0DU6jwfKQjNw1J0TJ3zJ5dZoC4BAS7O8ByRBWPIIeOs3qmdgbYzL_iMXyVU',NULL,NULL,'2025-12-02 14:05:34','2025-12-02 14:05:36');
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_zipcodes`
--

DROP TABLE IF EXISTS `tbl_zipcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_zipcodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `zipcodes` text,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_zipcodes`
--

LOCK TABLES `tbl_zipcodes` WRITE;
/*!40000 ALTER TABLE `tbl_zipcodes` DISABLE KEYS */;
INSERT INTO `tbl_zipcodes` VALUES (2,'60601,60602,60603,60604,60605,60606,60607,60608,60609,60610,60611,60612,60613,60614,60615,60616,60617,60618,60619,60620,60621,60622,60623,60624,60625,60626,60628,60629,60630,60631,60632,60633,60634,60636,60637,60638,60639,60640,60641,60642,60643,60644,60645,60646,60647,60649,60651,60652,60653,60654,60655,60656,60657,60659,60660,60661,60706,60707,60714','2025-12-02 01:01:46','2025-12-02 01:01:46');
/*!40000 ALTER TABLE `tbl_zipcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '26.0.0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES (4,'28.0.3','2025-12-02 07:01:47','2025-12-02 07:01:47');
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'taist_local'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02  8:58:34
